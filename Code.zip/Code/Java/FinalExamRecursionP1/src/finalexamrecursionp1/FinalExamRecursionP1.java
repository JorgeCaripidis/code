/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalexamrecursionp1;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class FinalExamRecursionP1 {

    public static void rRemoveEven(ArrayList<Integer> al, int n) {
        if (n < 0) {
            return;
        } else if (al.get(n) % 2 == 0) {
            al.remove(n);
        }
        rRemoveEven(al, n - 1);
    }

    public static void populateArrayList(ArrayList<Integer> al, int size) {
        Random rnd = new Random();
        for (int i = 0; i < size; i++) {
            al.add(rnd.nextInt(10 - 0 + 1) + 0);
        }
    }

    public static void printArrayList(ArrayList<Integer> al) {
        for (int i = 0; i < al.size(); i++) {
            System.out.println(al.get(i));
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Give me the list size: ");
        int size = s.nextInt();
        ArrayList<Integer> A = new ArrayList();
        populateArrayList(A, size);
        printArrayList(A);
        rRemoveEven(A, A.size() - 1);
        System.out.println("----------------------------------------------------------------------------");
        printArrayList(A);
    }

}
