/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproblem5;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class FinalProblem5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Type your words (first word, second word)");
        String str1 = s.nextLine();
        String str2 = s.nextLine();
        if ((compareStrings(str1, str2)) && (compareStrings(str2, str1))) {
            System.out.println("1");
        } else {
            System.out.println("0");
        }
    }

    public static boolean compareStrings(String str1, String str2) {
        for (int i = 0; i < str1.length(); i++) {
            if (!str2.contains(Character.toString(str1.charAt(i)))) {
                return false;
            }
        }
        return true;
    }
}
