/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework3_problem3;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author JORGE "The Greek Hacker" Caripidis
 */
public class Homework3_Problem3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        Random rnd = new Random();
        System.out.print("Enter array size: ");
        int n = s.nextInt();
        int[] sortedArray = new int[n];
        ArrayList<Integer> A = new ArrayList();
        for (int i = 0; i < n; i++) {
            A.add(rnd.nextInt(100));

        }
        printArrayList(A);
        for (int i = 0; i < sortedArray.length; i++) {
            sortedArray[i] = removeMax(A);
        }
        reverseArray(sortedArray);
        System.out.println(Arrays.toString(sortedArray));

    }

    public static int removeMax(ArrayList<Integer> lst) {
        int currentMax = 0;
        int maxIndex = 0;
        for (int i = 0; i < lst.size(); i++) {
            if (lst.get(i) > currentMax) {
                currentMax = lst.get(i);
                maxIndex = i;
            }

        }
        lst.remove(maxIndex);
        return currentMax;
    }

    public static int[] reverseArray(int[] arr) {
        for (int i = 0; i < (arr.length / 2); i++) {
            swap(arr, i, arr.length - 1 - i);
        }

        return arr;
    }

    public static void swap(int[] array, int i, int j) {
        int temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }

    public static void printArrayList(ArrayList<Integer> lst) {
        for (int i = 0; i < lst.size(); i++) {
            System.out.println(lst.get(i));
        }
    }
}
