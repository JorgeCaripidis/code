/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_problem2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Lab11_Problem2 {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the size of the array list:");
        int n = s.nextInt();
        ArrayList<Integer> A = new ArrayList();
        populateArrayList(A, n);
        System.out.print("Enter number you want ro add to the array list:");
        int number = s.nextInt();
        Collections.sort(A);
        printArrayList(A);
        System.out.println("----------------------------------------------");
        sortArrayList(A,number);
        printArrayList(A);
    }

    public static void populateArrayList(ArrayList<Integer> lst, int size) {
        Random rnd = new Random();
        for (int i = 0; i < size; i++) {
            lst.add(rnd.nextInt(100) + 1);
        }
    }

    public static void printArrayList(ArrayList<Integer> lst) {
        for (int i = 0; i < lst.size(); i++) {
            System.out.println(lst.get(i));
        }
    }

    public static void sortArrayList(ArrayList<Integer> a, int x) {
        int i;
        for (i = 0; i < a.size(); i++) {
            if (x <= a.get(i)) {
                a.add(i, x);
                break;
            }

        }
        if (i == a.size()) {
            a.add(x);
        }
    }
}
