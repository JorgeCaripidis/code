/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework3_problem2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author Jorge "The Greek Hacker" Caripidis
 */
public class Homework3_Problem2 {
static Random rnd = new Random();
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        
        System.out.print("Enter LowerBound for the range: ");
        double lowRange = s.nextInt();
        System.out.print("Enter UpperBound for the range: ");
        double highRange = s.nextInt();
        System.out.print("Enter Desired Accuracy for the range: ");
        int accuracy = s.nextInt();
        System.out.print(randomPreciseDoubles(lowRange,highRange,accuracy));
        
    }

    public static double randomPreciseDoubles(double L, double H, int A) {
        String precision = Integer.toString(A);
        String formatHelper = "%." + precision + "f";
        double randomDouble = L + (H - L) * rnd.nextDouble();
        randomDouble = Double.parseDouble(String.format(formatHelper, randomDouble));
        return randomDouble;
    }

}
