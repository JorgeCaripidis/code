/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bankdatabase;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class BankDatabase {

    static Connection con;
    static final String url = "jdbc:mysql://localhost/Bank";

    public static void main(String[] args) throws SQLException {

        try {

            con = (Connection) DriverManager.getConnection(url, "root", "MCS_2017");
            System.out.println("Connected to database " + url);
            System.out.println("/////////////////////////////////////////////////////////////////////////");
            System.out.println("To add an account type 1. To insert a customer type 2. To display accounts whose balance exceeds $50,000 type 3.");
            System.out.println("/////////////////////////////////////////////////////////////////////////");
//     
            Scanner s = new Scanner(System.in);
            int n = s.nextInt();
            if (n == 1) {
                addAccount aa = new addAccount(null, true);
                aa.setVisible(true);
            } else if (n == 2) {
                addCustomer ac = new addCustomer(null, true);
                ac.setVisible(true);
            } else if (n == 3) {
                Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
                String selectString = " SELECT * FROM bank.account;";
                ResultSet rs = st.executeQuery(selectString);

                while (rs.next()) {

                    double a = rs.getDouble("accountbalance");
                    if (a > 50000) {
                        System.out.println("/////////////////////////////////////////////////////////////////////////");
                        System.out.println(rs.getString("accountid"));
                        System.out.println(rs.getString("accounttype"));
                        System.out.println(a);
                    }
                }
                con.close();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
