/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codify;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Codify {

    public static String encode(String str, int k) {
        String temp = "";
        int number;
        for (int i = 0; i < str.length(); i++) {
            number = str.charAt(i) + k;
            if (number > 122) {
                number = number - 'z' + 'a' - 1;

            }
            temp += (char) (number);
        }
        return temp;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String str = s.nextLine();
        int k = s.nextInt();
        System.out.println(encode(str.toLowerCase(), k));
    }

}
