/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab1.jorge.caripidis;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Lab1JorgeCaripidis {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int[][] bidi = {{0, 0, 0, 0}, {1, 0, 0, 0}, {2, 3, 0, 0}, {4, 5, 6, 0}};
        int sum = 0;
        for (int i = 1; i < bidi.length; i++) {
            for (int j = 0; j <= i-1; j++) {
                sum = sum + bidi[i][j];
               
            }
        }
    System.out.println(sum); 
    }
}
