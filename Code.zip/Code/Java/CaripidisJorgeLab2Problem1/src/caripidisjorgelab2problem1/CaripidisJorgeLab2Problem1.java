/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caripidisjorgelab2problem1;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class CaripidisJorgeLab2Problem1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Type a string");
        String str = s.nextLine();
        System.out.println(numericalValueString(str));
    }

    public static int numericalValueString(String str) {
        int sum = 0;
        for (int i = 0; i < str.length(); i++) {
            sum += str.charAt(i);
        }
        return sum;
    }
}
