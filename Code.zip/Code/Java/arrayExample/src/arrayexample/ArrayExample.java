/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrayexample;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class ArrayExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Random rnd = new Random();
       Scanner s = new Scanner(System.in);
//       int n= s.nextInt();
//       int[] A = new int [n];
////       for (int i=0;i<A.length;i++)
//       {
//           A[i] = rnd.nextInt(41) - 20;    //Numbers from a to b: [a,b-a+1]
//           //Example: a = -20, b = 20 range = [-20,20-(-20)+1]
//        System.out.println(A[i]);
//       }
       String str;
       while(true)
       {
    str = s.next();
    if (!str.equals("r")) break;
    System.out.println("(" + (rnd.nextInt(6) + 1) + "," + (rnd.nextInt(6)+1) + ")");
       }
    }
    
}