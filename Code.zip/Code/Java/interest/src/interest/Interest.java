/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interest;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Interest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        double p;   //principal
        double ir;  //annual interest rate
        int comp;   //compounding
        int years;  //number of years principal is deposited
        double finalAmount; //money accumulated 
        System.out.print("Enter Principal:");
        p = s.nextDouble();
        finalAmount = p;
        System.out.print("Enter Annual Interest Rate:");
        ir = s.nextDouble();
        System.out.print("Enter Compunding Method (1 for yearly, 12 for monthly, etc.):");
        comp = s.nextInt();
        System.out.print("Enter Number of Years:");
        years = s.nextInt();
        for (int i = 1;i <= years;i++)
        {
            finalAmount = finalAmount*(1 + ir/100/comp);
        }
        System.out.println("Your principle of " + p);
        System.out.println("deposite for " + years + "years");
        System.out.println("with an annual interest rate of " + ir);
        System.out.println("compounded " + comp + " times a year");
        System.out.println("will earn you " + finalAmount + " dollars");
            
    }
    
}
 