/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam2problem1;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Exam2Problem1 {

    public static String swapFirstHalf(String str1, String Str2)
    {
        
    }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        String str1 = s.nextLine();
        String str2 = s.nextLine();
    }
    
}
