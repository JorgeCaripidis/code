/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw2problem1cartesianproduct;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author joanc
 */
public class Hw2Problem1CartesianProduct {

    public static String rElementAndArray(int el, int[] f, int n) {
        if (n == 0) {
            return "";
        } else {
            return "(" + el + "," + f[n - 1] + ")" + rElementAndArray(el, f, n - 1);
        }
    }

    public static String rCartesian(int[] A, int m, int[] B, int n) {
        if (m == 0) {
            return "";
        } else {
            return rElementAndArray(A[m - 1], B, n) + rCartesian(A, m - 1, B, n);
        }
    }

    public static void populateArray(int[] a) {
        Random rnd = new Random();
        for (int i = 0; i < a.length; i++) {
            a[i] = rnd.nextInt(10 - 1 + 1) + 1;
        }
    }

    public static void printArray(int[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter size of first array: ");
        int size1 = s.nextInt();
        int[] A = new int[size1];
        populateArray(A);
        printArray(A);
        System.out.print("Enter size of second array: ");
        int size2 = s.nextInt();
        int[] B = new int[size2];
        populateArray(B);
        printArray(B);
        System.out.println("Cartesian Product");
        System.out.println(rCartesian(A, A.length, B, B.length));
    }

}
