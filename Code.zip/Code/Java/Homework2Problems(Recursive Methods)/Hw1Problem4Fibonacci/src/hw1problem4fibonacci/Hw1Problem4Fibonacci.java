/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw1problem4fibonacci;

import java.util.Scanner;

/**
 *
 * @author joanc
 */
public class Hw1Problem4Fibonacci {

    static int count1 = 0;
    static int count2 = 0;

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter a number to find nth Fibonacci number: ");
        int num = s.nextInt();

        System.out.println("The Fibonacci number recursively of " + num + " is " + rFib(num));
        System.out.println("The Fibonacci number of " + num + " is " + Fib(num));
        System.out.println("Printing counts to see how long they take: ");
        System.out.println("Count for recursive method: " + count1);
        System.out.println("Count for iterative method: " + count2);
    }

    public static int rFib(int n) {//Fibonacci Recursive
        count1++;
        if (n == 0) {
            return 0;
        } else if (n == 1) {
            return 1;
        } else {
            return rFib(n - 1) + rFib(n - 2);
        }

    }

    public static int Fib(int n)//Fibonacci Iterative
    {
        count2++;
        int n1 = 0;
        int n2 = 1;
        for (int i = 1; i <= n; i++) {
            int temp = n1;
            n1 = n1 + n2;
            n2 = temp;
        }
        return n1;
    }
}
