/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw1problem2exponentiationrecursively;

import java.util.Scanner;

/**
 *
 * @author joanc
 */
public class Hw1Problem2ExponentiationRecursively {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter base: ");
        int b = s.nextInt();
        System.out.println("Enter exponent: ");
        int e = s.nextInt();
        System.out.println("Result: " + rExpo(b, e));
    }

    public static int rExpo(int base, int exp) {
        if (exp == 0) {
            return 1;
        } else if (exp == 1) {
            return base;
        } else {
            return base * rExpo(base, exp - 1);
        }

    }
}
