/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw1problem3primerecursively;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Hw1Problem3PrimeRecursively {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter number: ");
        int i = s.nextInt();
        System.out.println("integer:" + i + " is prime:" + rPrime(i, i / 2));

    }

    private static boolean rPrime(int n, int div) {
        if (n == 1) {
            return false;
        }
        if (div == 1) {
            return true;
        } else if (n % div == 0) {
            return false;
        } else {
            return rPrime(n, div - 1);
        }
    }
}
