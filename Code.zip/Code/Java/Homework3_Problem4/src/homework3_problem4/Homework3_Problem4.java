/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework3_problem4;

/**
 *
 * @author Jorge "The Greek Hacker" Caripidis
 */
public class Homework3_Problem4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Rectangle r1 = new Rectangle(5, 10, 15, 15);
        Rectangle r2 = new Rectangle(15, 20, 10, 20);
        if (r1.width == r2.width) {
            Rectangle r3 = new Rectangle(r1.loc.x, r1.loc.y, r1.width, Rectangle.joinRectangles(r1, r2));
            System.out.println("Your Width was the same, and your joined height was:");
            System.out.println(r3.height);
        } else if (r1.height == r2.height) {
            boolean bHeight = true;
            Rectangle r3 = new Rectangle(r1.loc.x, r1.loc.y, Rectangle.joinRectangles(r1, r2, bHeight), r1.height);
            System.out.println("Your Height was the same, and your joined width was:");
            System.out.println(r3.width);
        } else {
            System.out.println("Sorry Those Rectangles Can't Be Joined :(");
        }

    }

}
