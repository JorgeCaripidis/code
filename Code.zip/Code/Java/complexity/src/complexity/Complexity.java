/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package complexity;

/**
 *
 * @author stJo88Ca5517
 */
public class Complexity {

    /**
     * @param args the command line arguments
     */
    public static void singleLop()////  (Big O n)
    {
        int n = 100;
        int sum = 0, count = 0;
        for (int i = 0; i < n; i += 2) {
            sum += i;
            count++;
        }
        System.out.println("Execution counter = " + count);
    }

    public static void singleLop2()//////  O(logbase100 of (n))
    {
        int n = 100;
        int sum = 0, count = 0;
        for (int i = 1; i < n; i *= 2) {
            sum += i;
            count++;
        }
        System.out.println("Execution counter = " + count);
    }

    public static void singleLop3()//////  O(log(log n))
    {
        int n = 1000000000;
        int sum = 0, count = 0;
        for (int i = 0; i < n; i = (int) Math.exp(i)) {
            sum += i;
            count++;
        }
        System.out.println("Execution counter = " + count);
    }

    public static void doubleLop()//////  O(n^2)
    {
        int n = 100;
        int sum = 0, count = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                sum += i;
                count++;
            }
        }
        System.out.println("Execution counter = " + count);
    }
 public static void doubleLop2()//////  O(n^2)
    {
        int n = 100;
        int sum = 0, count = 0;
        for (int i = 1; i <= n; i++) {
            for (int j = i; j <= n; j++) {
                sum += i;
                count++;
            }
        }
        System.out.println("Execution counter = " + count);
    }
    public static void main(String[]args)
    {
        doubleLop2();
    }
}
