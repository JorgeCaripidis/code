/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caripidislab6problem1;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class CaripidisLab6Problem1 {

    public static void populateArray(int[] a) {
        Random rnd = new Random();
        for (int i = 0; i < a.length; i++) {
            a[i] = rnd.nextInt(10 - (-10) + 1) - 10;
        }
    }

    public static void printArray(int[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
    }

    public static void rMerge(int[] a, int low, int high) {
        int mid = (low + high) / 2;
        int low1 = low;
        int low2 = mid + 1;
        int[] c = new int[high - low + 1];
        int k = 0;
        while ((low1 <= mid) && (low2 <= high)) {
            if (a[low1] < a[low2]) {
                c[k++] = a[low1++];
            } else {
                c[k++] = a[low2++];
            }
        }
        while (low1 <= mid) {
            c[k++] = a[low1++];
        }
        while (low2 <= high) {

            c[k++] = a[low2++];
        }
        k = 0;
        for (int i = low; i <= high; i++) {

            a[i] = c[k++];
        }
    }

    public static void rMergeSort(int[] a, int low, int high) {
       
        if (low == high) {
            return;
        } else {
            int mid = (low + high) / 2;

            rMergeSort(a, low, mid);
            rMergeSort(a, mid + 1, high);
            rMerge(a, low, high);
        }
       
    }

    public static void bubbleSort(int[] a) {// O(n^2) complexity
        for (int i = 0; i < a.length - 1; i++) {
            for (int j = 0; j < a.length - 1 - i; j++) {
                if (a[j] > a[j + 1]) {
                    int temp = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp;
                }
            }
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Choose array size: ");
        int n = s.nextInt();
        int[] A = new int[n];
        populateArray(A);
//        System.out.println("Array A: ");
//        printArray(A);
        int[] B = A.clone();
//        System.out.println("Array B: ");
//        printArray(B);
        System.out.println("------------------------------------------------------------------------");
        System.out.println("BubbleSort Time: ");
        long start = System.nanoTime();
        bubbleSort(A);
        long end = System.nanoTime();
        System.out.println(end - start);
//        printArray(A);
        System.out.println("rMergeSort: ");
        long start2 = System.nanoTime();
        rMergeSort(B, 0, B.length-1);
        long end2 = System.nanoTime();
        System.out.println(end2 - start2);
//        printArray(B);
    }

}
