
import java.awt.Color;
import java.awt.Image;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.TransferHandler;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author stJo88Ca5517
 */
public class Problem1Final extends javax.swing.JFrame {

    JLabel l1, l2, l3, l4, l5, l6, l7, l8, l9, lt;

    public Problem1Final() {
        super("Drag and Drop Game");
        initComponents();
        l1 = new JLabel();
        l2 = new JLabel();
        l3 = new JLabel();
        l4 = new JLabel();
        l5 = new JLabel();
        l6 = new JLabel();
        l7 = new JLabel();
        l8 = new JLabel();
        l9 = new JLabel();
        lt = new JLabel();
        l1.setBounds(20, 20, 350, 200);
        l2.setBounds(370, 20, 350, 200);
        l3.setBounds(720, 20, 350, 200);
        l4.setBounds(20, 220, 350, 200);
        l5.setBounds(370, 220, 350, 200);
        l6.setBounds(720, 220, 350, 200);
        l7.setBounds(20, 420, 350, 200);
        l8.setBounds(370, 420, 350, 200);
        l9.setBounds(720, 420, 350, 200);
        lt.setBounds(370, 680, 350, 200);

        try {
            Random rand = new Random();
            int[] map = new int[9];
            JLabel[] jLabel = {l1, l2, l3, l4, l5, l6, l7, l8, l9};
            ArrayList<Integer> image = new ArrayList<>();
            image.add(1);
            image.add(2);
            image.add(3);
            image.add(4);
            image.add(5);
            image.add(6);
            image.add(7);
            image.add(8);
            image.add(9);
            for (int i = 0; i < 9; i++) {
                int index = rand.nextInt(image.size());
                int num = image.get(index);
                displayImage(ImageIO.read(new File(num + ".jpg")), jLabel[i]);
                image.remove(index);
            }

            lt.setBorder(BorderFactory.createLineBorder(Color.black));
        } catch (IOException e) {

        }
        MouseListener m = new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {

            }

            @Override
            public void mousePressed(MouseEvent e) {
                JComponent jc = (JComponent) e.getSource();
                TransferHandler th = jc.getTransferHandler();
                th.exportAsDrag(jc, e, TransferHandler.COPY);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {

            }

            @Override
            public void mouseExited(MouseEvent e) {

            }
        };

        l1.addMouseListener(m);

        l2.addMouseListener(m);

        l3.addMouseListener(m);

        l4.addMouseListener(m);

        l5.addMouseListener(m);

        l6.addMouseListener(m);

        l7.addMouseListener(m);

        l8.addMouseListener(m);

        l9.addMouseListener(m);

        lt.addMouseListener(m);

        l1.setTransferHandler(
                new TransferHandler("icon"));
        l2.setTransferHandler(
                new TransferHandler("icon"));
        l3.setTransferHandler(
                new TransferHandler("icon"));
        l4.setTransferHandler(
                new TransferHandler("icon"));
        l5.setTransferHandler(
                new TransferHandler("icon"));
        l6.setTransferHandler(
                new TransferHandler("icon"));
        l7.setTransferHandler(
                new TransferHandler("icon"));
        l8.setTransferHandler(
                new TransferHandler("icon"));
        l9.setTransferHandler(
                new TransferHandler("icon"));
        lt.setTransferHandler(
                new TransferHandler("icon"));

        add(l1);

        add(l2);

        add(l3);

        add(l4);

        add(l5);

        add(l6);

        add(l7);

        add(l8);

        add(l9);

        add(lt);

        setLayout(
                null);
        setSize(1000, 500);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        this.setVisible(
                true);
    }

    private void displayImage(BufferedImage bi, JLabel lbl) {
        Image im = bi.getScaledInstance(lbl.getWidth(), lbl.getHeight(), BufferedImage.SCALE_SMOOTH);
        lbl.setIcon(new ImageIcon(im));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>                        

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Problem1Final.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Problem1Final.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Problem1Final.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Problem1Final.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Problem1Final().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    // End of variables declaration                   
}
