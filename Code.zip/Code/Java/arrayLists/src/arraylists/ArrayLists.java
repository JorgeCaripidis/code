/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arraylists;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class ArrayLists {

    public static void populateArrayList(ArrayList<Integer> al, int size, int a, int b) {
        Random rnd = new Random();
        for (int i = 0; i < size; i++) {
            al.add(rnd.nextInt(b - a + 1) + a);
        }
    }

    public static void deleteEvenArrayList(ArrayList<Integer> al) {
        for (int i = 0; i < al.size(); i++) {
            if (al.get(i) % 2 == 0) {
                al.remove(i);
                i--;
            }
        }
    }

    public static void reverseArrayList(ArrayList<Integer> al) {
        Integer temp;
        for (int i = 0; i < al.size() / 2; i++) {
            temp = al.get(i);
            al.set(i, al.get(al.size() - 1 - i));
            al.set(al.size() - 1 - i, temp);
        }
    }

    public static void printArrayList(ArrayList<Integer> al) {
        for (int i = 0; i < al.size(); i++) {
            System.out.println(al.get(i));
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Give me the list size: ");
        int size = s.nextInt();
        System.out.print("Give me the range of values: ");
        int n1 = s.nextInt();
        int n2 = s.nextInt();
        ArrayList<Integer> A = new ArrayList();
        populateArrayList(A, size, n1, n2);
        printArrayList(A);
        System.out.println("--------------------- ");
//        reverseArrayList(A);
//        printArrayList(A);
        deleteEvenArrayList(A);
        printArrayList(A);
    }

}
