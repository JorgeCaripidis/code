/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package freq;

/**
 *
 * @author stJo88Ca5517
 */
public class Freq {

    public static void calcFreq(String str, int[] f) {
        char ch;
        str = str.toLowerCase();
        for (int i = 0; i < str.length(); i++) {
            ch = str.charAt(i);
            if ((ch >= 'a') && (ch <= 'z')) {
                f[ch - 97]++;
            }
        }

    }

    public static void printArray(int[] a) {
        for (int i = 0; i < a.length; i++) {
            System.out.println(a[i]);
        }
    }

    public static void main(String[] args) {
        String str = "Hello world";
        int[] freq = new int[26];
        calcFreq(str, freq);
        printArray(freq);
    }

}
