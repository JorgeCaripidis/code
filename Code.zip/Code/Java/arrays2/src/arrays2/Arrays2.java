/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays2;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Arrays2 {

    public static void populateArray(int[] a) {
        Random rnd = new Random();
        for (int i = 0; i < a.length; i++) {
            a[i] = rnd.nextInt(21);
        }
    }

    public static void pairArrays(int[] a, int[] b) {
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < b.length; j++) {
                System.out.print("(" + a[i] + "," + b[j] + ")");
                System.out.print("(" + b[j] + "," + a[i] + ")");
            }
            System.out.println();
        }
        System.out.println("---------------------------------");
    }
    public static int[] createRandomArray(int size, int a,int b)
    {
        Random rnd = new Random();
        int[] temp = new int[size];
        for (int i = 0; i < temp.length; i++) {
            temp[i] = rnd.nextInt(b - a + 1) + a;
        
    }
        return temp;
    }
    public static void printArray(int [] a)
    {
        for (int i=0; i<a.length; i++)
            System.out.println(a[i]);
    }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n = s.nextInt();
        int[] A = createRandomArray(n,-10,10);
        printArray(A);
//        int[] B = new int[n];
//        int[] C = new int[3];
//        populateArray(A);
//        populateArray(B);
//        populateArray(C);
//        pairArrays(A, B);
//        pairArrays(A, C);

    }
}
