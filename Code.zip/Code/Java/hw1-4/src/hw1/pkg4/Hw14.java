/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw1.pkg4;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Hw14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int sum = 0;
        int total = 0;
        int n = s.nextInt();
        int i;
        for (i=1;i<=n;i++)
    {
        sum = sum + i*i;
    }
        total = total + ((2*n*n*n)+(3*n*n)+n);
        total = total/6;
        if (sum == total)
                System.out.println("Proven");
        else 
                System.out.println("False");
    }
    
}
