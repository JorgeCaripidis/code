/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caripidislab4cs231;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class CaripidisLab4CS231 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter amount:");
        int price = (int) (100*s.nextDouble());
        int quarter= 25;
        int dime= 10;
        int nickel= 5;
        int penny= 1;
        int countq;
        int countd;
        int countn;
        int countp;
        countq= price/quarter;
        price= price % quarter;
        countd= price/dime;
        price= price % dime;
        countn= price/nickel;
        price= price % nickel;
        countp=price;
        System.out.println(countq + " quarters " + countd + " dimes " + countn + " nickels " + countp + " pennies");
                
    }
    
}
