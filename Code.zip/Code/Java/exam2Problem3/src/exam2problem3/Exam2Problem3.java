/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam2problem3;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Exam2Problem3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        Random rnd = new Random();
        System.out.print("Enter array size: ");
        int n = s.nextInt();
        int[] A = new int[n];
        int counteven = 0;
        int countodd = 0;
        for (int i = 0; i < A.length; i++) {
            A[i] = rnd.nextInt(10);
        }
        for (int i = 0; i < A.length; i++) {
            if (A[i] % 2 == 0) {
                counteven++;
            } else if (A[i] % 2 != 0) {
                countodd++;
            }
            System.out.println(Arrays.toString(A));
        }
        if (counteven > countodd) {
            System.out.println("Evens are more");
        }
        if (countodd > counteven) {
            System.out.println("Odds are more");
        }
        if (countodd == counteven) {
            System.out.println("There is an equal number of odds and evens");
        }
    }

}
