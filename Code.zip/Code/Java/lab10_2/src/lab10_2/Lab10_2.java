/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10_2;

import java.util.ArrayList;
import static java.util.Collections.list;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Lab10_2 {

    public static boolean isPrime(long number) {
        int div = 2;
        long limit = (long) Math.sqrt(number);
        if (number <= 1) {
            return false;
        } else if (number == 2) {
            return true;
        } else {
            while (div <= limit) {
                if (number % div == 0) {
                    return false;
                }
                div++;
            }
        }
        return true;
    }

    public static void printArrayList(ArrayList<Integer> lst) {
        for (int i = 0; i < lst.size(); i++) {
            System.out.println(lst.get(i));
        }
    }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        long number = s.nextLong();
        ArrayList<Integer> A = new ArrayList();
        A.add(1);
        for (int i = 2; i <= number; i++) {
            if (isPrime(i)) {
                A.add(i);
              
            }
        }  
        printArrayList(A);
    }
}
