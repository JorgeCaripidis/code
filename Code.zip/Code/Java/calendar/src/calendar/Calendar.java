/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calendar;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Calendar {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner (System.in);
        int month, day, number, extra;
        String dow;
        System.out.println("Enter month (1-12):");
        month = s.nextInt();
        System.out.println("Enter day (1-31):");
        day = s.nextInt();
        System.out.println("Enter weekday (0-6):");
        dow = s.next();
        switch (dow)
        {
            case "Sunday":      number = 0;
                                break;
            case "Monday":      number = 1;
                                break;
            case "Tuesday":     number = 2;
                                break;
            case "Wednesday":   number = 3;
                                break;
            case "Thursday":    number = 4;
                                break;
            case "Friday":      number = 5;
                                break;
            case "Sturday":     number = 6;
                                break;
            default:            number = -1;
                                break;           
        }
        switch (month) {
            case 1:  extra = 3;
                     break;
            case 2:  extra = 0;
                     break;
            case 3:  extra = 3;
                     break;
            case 4:  extra = 2;
                     break;
            case 5:  extra = 3;
                     break;
            case 6:  extra = 2;
                     break;
            case 7:  extra = 3;
                     break;
            case 8:  extra = 3;
                     break;
            case 9:  extra = 2;
                     break;
            case 10: extra = 3;
                     break;
            case 11: extra = 2;
                     break;
            case 12: extra = 3;
                     break;
            default: extra = 0;
                     System.out.println("Wrong month number");
                     break;
    }
    System.out.println("Add " + extra + " days");
    number = (number + extra) % 7;
    switch(number)
    {
        case 0: dow = "Sunday";
            break; 
        case 1: dow = "Monday";
            break; 
        case 2: dow = "Tuesday";
            break; 
        case 3: dow = "Wednesday";
            break; 
        case 4: dow = "Thursday";
            break; 
        case 5: dow = "Friday";
            break;
        case 6: dow = "Saturday";
            break; 
        default:dow = "Error!";
    }
    System.out.println("The day for next month is: " + dow);
}
      
    
}
