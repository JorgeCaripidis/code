/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam2problem2;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Exam2Problem2 {

    public static int factorial(int a) {
        int result = 1;
        for (int i = 1; i <= a; i++) {
            result = result * i;
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter your number:");
        int number = s.nextInt();
        System.out.println(factorial(number));
    }

}
