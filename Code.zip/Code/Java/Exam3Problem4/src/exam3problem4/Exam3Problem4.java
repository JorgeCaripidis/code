/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam3problem4;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Exam3Problem4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        ArrayList<Integer> A = new ArrayList();
        System.out.print("Enter the size of the array list:");
        int n = s.nextInt();
        populateArrayList(A, n);
        printArrayList(A);
        System.out.println("------------------");
        shrinkArrayList(A);
        printArrayList(A);

    }

    public static void populateArrayList(ArrayList<Integer> lst, int size) {
        Random rnd = new Random();
        for (int i = 0; i < size; i++) {
            lst.add(rnd.nextInt(11));
        }
    }

    public static void printArrayList(ArrayList<Integer> lst) {
        for (int i = 0; i < lst.size(); i++) {
            System.out.println(lst.get(i));
        }

    }

    public static void shrinkArrayList(ArrayList<Integer> lst) {

        if (lst.size() % 2 == 0) 
            for (int i = 0; i < lst.size(); i++) {
                lst.set(i, lst.get(i) + lst.get(i + 1));
                lst.remove(lst.get(i + 1));
            }
            else
                for (int i = 0; i < lst.size() -1; i++) {
                lst.set ( i , lst.get(i) + lst.get(i+1)) ;  
                lst.remove(lst.get(i + 1));
           }

            }
        }
    

