/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caripidislab6problem2;

import java.math.BigInteger;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class CaripidisLab6Problem2 {

    public static BigInteger factorialBigInt(BigInteger n) {
        BigInteger fact = BigInteger.ONE;
        
        for (BigInteger i = BigInteger.ONE; i.compareTo(n) <= 0; i = i.add(BigInteger.ONE)) {
            fact = fact.multiply(i);
        }
        return fact;
    }

    public static BigInteger rFact(BigInteger n) {
        if (n.equals(BigInteger.ZERO)) {
            return BigInteger.ONE;
        } else {
            return n.multiply(rFact(n.subtract(BigInteger.ONE)));
        }

    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Type number for which you want to compute the factorial: ");
        BigInteger n = s.nextBigInteger();
        long start = System.nanoTime();
        //System.out.print("Factorial Iterative: ");
        System.out.println(factorialBigInt(n));
        long end = System.nanoTime();
        System.out.print("Time: ");
        System.out.println(end - start);
        long start2 = System.nanoTime();
        //System.out.print("Factorial Recursively: ");
        System.out.println(rFact(n));
        long end2 = System.nanoTime();
        System.out.print("Time: ");
        System.out.println(end2 - start2);

    }

}
