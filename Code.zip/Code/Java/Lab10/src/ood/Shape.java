/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood;

import java.awt.Point;

/**
 *
 * @author stJo88Ca5517
 */
public class Shape {

    Point loc;

    public Shape(Point p) {
        loc = new Point(p);

    }

    public Shape(int x, int y) {
        loc = new Point(x, y);

    }

    public Shape() {
        loc = new Point(0, 0);

    }

    public void printLocation() {
        System.out.println(loc);
    }

    public Point getLocation() {
        return loc;
    }

    public double area() {
        return 0;
    }

    public String relativeLocation(Shape s1) {
        if (loc.x < s1.loc.x) {
            if (loc.y < s1.loc.y) {
                return "SW";
            } else if (loc.y > s1.loc.y) {
                return "NW";
            } else {
                return "W";
            }
        } else if (loc.x > s1.loc.x) {
            if (loc.y < s1.loc.y) {
                return "SE";
            } else if (loc.y > s1.loc.y) {
                return "NE";
            } else {
                return "E";
            }
        } else {
            if (loc.y < s1.loc.y) {
                return "S";
            } else if (loc.y > s1.loc.y) {
                return "N";
            } else {
                return "Same Location";
            }
        }
    }
}
