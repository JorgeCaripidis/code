/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ood;

import java.awt.Point;

/**
 *
 * @author stJo88Ca5517
 */
public class Rectangle extends Shape {
    int width, height;
    public Rectangle(int x, int y, int w, int h)
    {
        loc = new Point (x,y);
        width = w;
        height = h;
    }
    @Override
    public double area()
{
    return width*height;
}
}
