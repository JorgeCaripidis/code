/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab10;

import ood.Circle;
import ood.Rectangle;
import ood.Shape;

/**
 *
 * @author stJo88Ca5517
 */
public class Lab10 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        {
        Shape sh = new Shape(5,10);
        Circle c = new Circle(3,4,4.5);
        System.out.println(c.relativeLocation(sh));
        System.out.println(sh.relativeLocation(c));
        Rectangle r = new Rectangle(5,10,10,20);
        System.out.println(r.relativeLocation(sh));
        System.out.println(sh.relativeLocation(r));
        }
    }
    
}
