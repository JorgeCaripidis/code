/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw1;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Hw1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner (System.in);
        int a,b,c;
        int max, max1;
        a = s.nextInt();
        b = s.nextInt();
        c = s.nextInt();
        if (a>b)
            max1 = a;
        else
            max1 =b;
        if (max1>c)
            max = max1;
        else
            max = c;
        System.out.println(max);
                    
    }
    
}
