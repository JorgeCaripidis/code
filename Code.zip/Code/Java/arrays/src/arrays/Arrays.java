/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arrays;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Arrays {

   public static int dotProd(int [] a, int [] b)
   {
     int dp = 0;
     for (int i=0; i<a.length;i++)
        {
           dp += a[i] * b[i];
 
        }
     return dp;
   }
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        Random rnd = new Random();
        System.out.print("Enter array size: ");
        int n= s.nextInt();
        int[] A = new int [n];
        int[] B = new int [n];
/////////////////////////////////////////////////////////////////////
//COMPUTING THE AVERAGE ARRAY VALUE
/////////////////////////////////////////////////////////////////////        
//        int sum = 0;
//        for (int i =0;i<A.length; i++)
//        {
//        A[i] = rnd.nextInt(10);
//        sum += A[i];
//        System.out.println(A[i]);
//        }
//        System.out.println((double)sum/A.length);
////////////////////////////////////////////////////////////////////
//FINDING THE MAXIMUN ARRAY VALUE
////////////////////////////////////////////////////////////////////
//        int max = A[0];
//        for (int i=1; i<A.length; i++)
//            if (max <A[i]) max = A[i];
//        System.out.println("Max = " + max);
//////////////////////////////////////////////////////////////////////
//CREATING AN ARRAY WITH RNDIOM VALUES
//////////////////////////////////////////////////////////////////////
    System.out.println("Array A:");
for (int i =0;i<A.length; i++)
        {
            A[i] = rnd.nextInt(10);
            System.out.println(A[i]);
        }
    System.out.println("Array B:");
for (int i =0;i<B.length; i++)
        {
            B[i] = rnd.nextInt(10);
            System.out.println(B[i]);
        }
//    ////////////////////////////////////////////////////////////////
//    REVERSING AN ARRAY
//    ////////////////////////////////////////////////////////////////
//  for (int i =0;i<A.length/2; i++)
//        {
//        int temp = A[i];
//        A[i] = A[A.length - 1- i];
//        A[A.length - 1- i]= temp;
//         }
  System.out.println("----------");
  int [] C = new int [n];
   System.out.println("The sum of the 2 arrays is: " );
  for (int i =0;i<A.length; i++)
        {
            C[i] = A[i] + B[i];
            System.out.println(C[i]);
        }
  int dotProduct = 0;
  for (int i =0;i<A.length; i++)
        {
            dotProduct += A[i] * B[i];
 
        }
  System.out.println("The dotproduct is: " + dotProduct);
    }
}