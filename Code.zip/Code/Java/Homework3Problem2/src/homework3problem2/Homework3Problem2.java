/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework3problem2;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author stJo88Ca5517
 */
public class Homework3Problem2 {

    static Connection con;
    static final String url = "jdbc:mysql://localhost/university";

    public static void main(String[] args) {
        try {
            loginHW3 ld = new loginHW3(null, true);
            ld.setVisible(true);
            String username = ld.username;
            String password = ld.password;
            con = (Connection) DriverManager.getConnection(url, username, password);
//            con = (Connection) DriverManager.getConnection(url, "root", "MCS_2017");
            System.out.println("Connected to database " + url);
            mainHW3 md = new mainHW3(null, true);
            md.setVisible(true);
        con.close();
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}
