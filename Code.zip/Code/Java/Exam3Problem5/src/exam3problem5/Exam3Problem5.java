/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam3problem5;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Exam3Problem5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner s = new Scanner(System.in);
        System.out.print("Enter the size of the first array list:");
        ArrayList<Integer> A = new ArrayList();
        ArrayList<Integer> B = new ArrayList();
        ArrayList<Integer> C = new ArrayList();
        int n1 = s.nextInt();
        System.out.print("Enter the size of the second array list:");
        int n2 = s.nextInt();
        populateArrayList(A, n1, -10, 10);
        populateArrayList(B, n2, -10, 10);
        printArrayList(A);
        System.out.println("-------------------------------------");
        printArrayList(B);
        System.out.println("-------------------------------------");
        C = positiveNumberOfTwoArrayLists(A, B);
        printArrayList(C);
        
    }
     public static void populateArrayList(ArrayList<Integer> lst, int size, int a, int b)
   {
       Random rnd = new Random();
       for (int i=0; i<size; i++)
           lst.add(rnd.nextInt(b-a+1)+a);
    }

    public static void printArrayList(ArrayList<Integer> lst) {
        for (int i = 0; i < lst.size(); i++) {
            System.out.println(lst.get(i));
        }
    }
    public static ArrayList<Integer> positiveNumberOfTwoArrayLists(ArrayList<Integer> a, ArrayList<Integer> b) {
       ArrayList<Integer> c = new ArrayList();
        for (int i = 0; i < a.size(); i++){
            if ((a.get(i)>=0) && (!c.contains(a.get(i))))
                c.add(a.get(i));
        }
            for (int i = 0; i < b.size(); i++){
                if (((b.get(i)>=0) && (b.get(i) != a.get(i))) && (!c.contains(b.get(i))))
                c.add(b.get(i));
            }
            return c;
        }
    }


