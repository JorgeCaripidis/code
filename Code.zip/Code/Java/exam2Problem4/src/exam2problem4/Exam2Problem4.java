/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam2problem4;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Exam2Problem4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.println("Enter your string: ");
        String str = s.nextLine();
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if ((str.charAt(i) >= 'a') && (str.charAt(i) <= 'z')
                    || (str.charAt(i) >= 'A') && (str.charAt(i) <= 'Z')) {
                count++;
            }
        }
        System.out.println("Number of alphabetic characters = " + count);
    }

}
