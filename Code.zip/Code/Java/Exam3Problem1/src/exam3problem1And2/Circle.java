/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam3problem1And2;

import java.awt.Point;

/**
 *
 * @author stJo88Ca5517
 */
public class Circle extends Shape {

    double radius;

    public Circle(double r) {
        loc = new Point(0, 0);
        radius = r;
    }

    public Circle(Point p, double r) {
        loc = new Point(p);
        radius = r;
    }

    public Circle(int x, int y, double r) {
        loc = new Point(x, y);
        radius = r;
    }

    @Override
    public double area() {
        return Math.PI * radius * radius;
    }
    public void Scale (double factor)
    {
        radius += Math.sqrt(factor);
    }
}
