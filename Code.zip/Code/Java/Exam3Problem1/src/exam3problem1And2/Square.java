/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam3problem1And2;

/**
 *
 * @author stJo88Ca5517
 */
public class Square extends Rectangle {
    int side;
   public Square(int x, int y, int side)
   {
       super(x, y, side, side);
       this.side = side;
   }
   public Square (int side)
   {
       super(0,0,side,side);
   }
   @Override
       public double area()
       {
           return side*side;
       }
}
