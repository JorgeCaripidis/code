/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author stJo88Ca5517
 */
public class Database {

    static Connection con;
    static final String url = "jdbc:mysql://localhost/university";

    public static void main(String[] args) {
        try {
            loginDialog ld = new loginDialog(null, true);
            ld.setVisible(true);
            String username = ld.username;
            String password = ld.password;
            con = (Connection) DriverManager.getConnection(url, username, password);
//            con = (Connection) DriverManager.getConnection(url, "root", "MCS_2017");
            System.out.println("Connected to database " + url);
            Statement st = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
            String selectString = " SELECT * FROM university.student;";
            ResultSet rs = st.executeQuery(selectString);
            while (rs.next()) {
                System.out.println(rs.getString("sid"));
                System.out.println(rs.getString("name"));
                System.out.println(rs.getString("gpa"));
            }
            con.close();
            mainDialog md = new mainDialog(null, true);
            md.setVisible(true);
        } catch (Exception e) {
            System.out.println(e);
        }

    }
}
