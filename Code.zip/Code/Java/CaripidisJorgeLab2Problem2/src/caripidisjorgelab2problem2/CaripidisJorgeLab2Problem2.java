/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package caripidisjorgelab2problem2;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class CaripidisJorgeLab2Problem2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Type a string: ");
        String str = s.nextLine();
        ArrayList<Integer> A = new ArrayList();
        System.out.print("Select size of the array: ");
        int size = s.nextInt();
        populateArrayList(A, size);
        printArrayList(A);
        cartesianProduct(A, str);
    }

    public static void cartesianProduct(ArrayList<Integer> lst, String str) {
        for (int i = 0; i < str.length(); i++) {
            for (int j = 0; j < lst.size(); j++) {
                if ((i!=str.length()-1) || (j!=lst.size()-1))
                System.out.print("(" + str.charAt(i) + "," + lst.get(j) + ")" + ";");
                else
                System.out.print("(" + str.charAt(i) + "," + lst.get(j) + ")");
            }
        }
    }

    public static void printArrayList(ArrayList<Integer> lst) {
        for (int i = 0; i < lst.size(); i++) {
            System.out.println(lst.get(i));
        }
    }

    public static void populateArrayList(ArrayList<Integer> lst, int size) {
        Random rnd = new Random();
        for (int i = 0; i < size; i++) {
            lst.add(rnd.nextInt(11));
        }
    }
}
