/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package flowchart3inprogram;

import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Flowchart3inprogram {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
         Scanner s = new Scanner(System.in);
         int a = s.nextInt();
         int b = s.nextInt();
         if ((a*a==b)||(b*b==a))
         System.out.println("yes");
         else 
         System.out.println("no");
    }
    
}
