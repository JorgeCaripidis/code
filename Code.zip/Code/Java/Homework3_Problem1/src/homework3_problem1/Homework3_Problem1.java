/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package homework3_problem1;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author JORGE "The Greek Hacker" Caripidis
 */
public class Homework3_Problem1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        Scanner s = new Scanner(System.in);
        Random rnd = new Random();
        System.out.print("Enter array size: ");
        int n = s.nextInt();
        ArrayList<Integer> A = new ArrayList();
        for (int i = 0; i <= n; i++) {
            A.add(rnd.nextInt(100));
            //A.add(10);
        }

        printArrayList(A);
        removeEven(A);
        System.out.println("Second Array: ");
        printArrayList(A);
    }

    public static void printArrayList(ArrayList<Integer> lst) {
        for (int i = 0; i < lst.size(); i++) {
            System.out.println(lst.get(i));
        }
    }

    public static void removeEven(ArrayList<Integer> lst) {
        for (int i = 0; i < lst.size(); i++) {
            if (lst.get(i) % 2 == 0) {
                lst.remove(i);
                i--;
            }

        }
    }

}
