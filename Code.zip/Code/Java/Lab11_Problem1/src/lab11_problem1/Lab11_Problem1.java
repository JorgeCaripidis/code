/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab11_problem1;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Lab11_Problem1 {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        ArrayList<Integer> A = new ArrayList();
        ArrayList<Integer> P = new ArrayList();
        ArrayList<Integer> NP = new ArrayList();
        System.out.print("Enter the size of the array list:");
        int n = s.nextInt();
        populateArrayList(A, n);
        splipPrimeNotprimeArrayList(A, P, NP);
        printArrayList(A);
        System.out.println("-------------------");
        printArrayList(P);
        System.out.println("-------------------");
        printArrayList(NP);
        P.add(1);

    }

    public static void populateArrayList(ArrayList<Integer> lst, int size) {
        Random rnd = new Random();
        for (int i = 0; i < size; i++) {
            lst.add(rnd.nextInt(100));
        }
    }

    public static void printArrayList(ArrayList<Integer> lst) {
        for (int i = 0; i < lst.size(); i++) {
            System.out.println(lst.get(i));
        }
    }

    public static boolean isPrime(long number) {
        int div = 2;
        long limit = (long) Math.sqrt(number);
        if (number <= 1) {
            return false;
        } else if (number == 2) {
            return true;
        } else {
            while (div <= limit) {
                if (number % div == 0) {
                    return false;
                }
                div++;
            }
        }
        return true;
    }

    public static void splipPrimeNotprimeArrayList(ArrayList<Integer> a, ArrayList<Integer> b, ArrayList<Integer> c) {
        for (int i = 0; i < a.size(); i++) {
            if ((isPrime(a.get(i))) || (a.get(i) == 1)) {
                b.add(a.get(i));

            } else {
                c.add(a.get(i));
            }
        }
    }
}
