/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exam3problem3;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author stJo88Ca5517
 */
public class Exam3Problem3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        ArrayList<Integer> A = new ArrayList();
        System.out.print("Enter the size of the array list:");
        int n = s.nextInt();
        Integer max = 0;
        populateArrayList(A, n);
        printArrayList(A);
        max = maxPrimeArray(A);
        System.out.println("------------------");
        System.out.println(max);

    }

    public static void populateArrayList(ArrayList<Integer> lst, int size) {
        Random rnd = new Random();
        for (int i = 0; i < size; i++) {
            lst.add(rnd.nextInt(20));
        }
    }

    public static void printArrayList(ArrayList<Integer> lst) {
        for (int i = 0; i < lst.size(); i++) {
            System.out.println(lst.get(i));
        }
    }

    public static Integer maxPrimeArray(ArrayList<Integer> lst) {
        Integer max = 0;
        for (int i = 0; i < lst.size(); i++) {
            if ((isPrime(lst.get(i))) && (lst.get(i) > max)) {
                max = lst.get(i);
            } else if ((max < lst.get(i)) && ((isPrime(lst.get(i))))) {
                max = lst.get(i);
            }
        }
        return max;
    }

    public static boolean isPrime(long number) {
        int div = 2;
        long limit = (long) Math.sqrt(number);
        if (number <= 1) {
            return false;
        } else if (number == 2) {
            return true;
        } else {
            while (div <= limit) {
                if (number % div == 0) {
                    return false;
                }
                div++;
            }
        }
        return true;
    }
}
